@echo off
set "XAMPP=C:\xampp"

if not exist "%XAMPP%\xampp_start.exe" (
    echo XAMPP was not found at %XAMPP%.
    echo Install XAMPP or edit the XAMPP path in this file.
    pause
    exit /b 1
)

start "XAMPP services" "%XAMPP%\xampp_start.exe"
timeout /t 3 /nobreak >nul
start "Source App" "http://localhost/Source-app/"
