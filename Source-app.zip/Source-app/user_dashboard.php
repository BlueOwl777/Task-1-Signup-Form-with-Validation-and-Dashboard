<?php

session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Page</title>
    <link rel="stylesheet" href="style.css?v=2">
</head>
<body>
    <button type="button" class="theme-toggle" onclick="toggleTheme()" aria-label="Switch theme">Dark mode</button>
    <div class="container dashboard-container">
        <h1>Welcome to the User Dashboard</h1>
        <p>Hello, <?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>! You are logged in as a user.</p>
        <div class="account-details">
            <h2>My Account</h2>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><a href="index.php?form=forgot-form">Forgot password?</a></p>
        </div>
        <button onclick="window.location.href='logout.php'">Logout</button>
    </div>

    <script src="script.js?v=6"></script>
</body>


</html>