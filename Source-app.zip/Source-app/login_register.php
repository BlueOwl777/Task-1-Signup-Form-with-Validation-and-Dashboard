<?php

session_start();
require_once 'config.php';

if (isset($_POST['forgot_password'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $strongPassword = strlen($newPassword) >= 8
        && preg_match('/[A-Z]/', $newPassword)
        && preg_match('/[a-z]/', $newPassword)
        && preg_match('/[0-9]/', $newPassword)
        && preg_match('/[^a-zA-Z0-9]/', $newPassword);

    if (!$strongPassword) {
        $_SESSION['forgot_error'] = "New password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
    } elseif ($newPassword !== $confirmPassword) {
        $_SESSION['forgot_error'] = "The new passwords do not match.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['forgot_error'] = "Please enter a valid email address.";
    } else {
        $lookupStatement = $conn->prepare("SELECT id FROM users WHERE username = ? AND email = ? LIMIT 1");
        $lookupStatement->bind_param('ss', $username, $email);
        $lookupStatement->execute();
        $userResult = $lookupStatement->get_result();

        if ($userResult->num_rows !== 1) {
            $_SESSION['forgot_error'] = "The username and email do not match an account.";
        } else {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $user = $userResult->fetch_assoc();
            $updateStatement = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $updateStatement->bind_param('si', $hashedPassword, $user['id']);
            $updateStatement->execute();
            $_SESSION['login_success'] = "Password changed successfully. You can now log in.";
        }
    }

    $_SESSION['active_form'] = !empty($_SESSION['forgot_error']) ? 'forgot-form' : 'login-form';
    header("Location: index.php");
    exit();
}

if (isset($_POST['register'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $plainPassword = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    $adminPassword = $_POST['admin_password'] ?? '';

    if ($role === 'admin' && !hash_equals($adminRegistrationPassword, $adminPassword)) {
        $_SESSION['register_error'] = "The Admin registration password is incorrect.";
        $_SESSION['active_form'] = 'register-form';
        header("Location: index.php");
        exit();
    }

    if (strlen($plainPassword) < 8 || !preg_match('/[A-Z]/', $plainPassword) || !preg_match('/[a-z]/', $plainPassword) || !preg_match('/[0-9]/', $plainPassword) || !preg_match('/[^a-zA-Z0-9]/', $plainPassword)) {
        $_SESSION['register_error'] = "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
        $_SESSION['active_form'] = 'register-form';
        header("Location: index.php");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($role, ['user', 'admin'], true)) {
        $_SESSION['register_error'] = "Please enter valid registration details.";
        $_SESSION['active_form'] = 'register-form';
        header("Location: index.php");
        exit();
    }

    $password = password_hash($plainPassword, PASSWORD_DEFAULT);

    $checkStatement = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $checkStatement->bind_param('s', $email);
    $checkStatement->execute();
    $checkEmail = $checkStatement->get_result();
    if ($checkEmail->num_rows > 0){
        $_SESSION['register_error'] = "Email already exists!";
        $_SESSION['active_form'] = 'register-form';

    } else {
        $insertStatement = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $insertStatement->bind_param('ssss', $username, $email, $password, $role);
        $insertStatement->execute();
    }

    header("Location: index.php");
    exit();
}

if (isset($_POST['login'])) {
    $loginValue = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $loginStatement = $conn->prepare("SELECT username, email, password, role FROM users WHERE email = ? OR username = ? LIMIT 1");
    $loginStatement->bind_param('ss', $loginValue, $loginValue);
    $loginStatement->execute();
    $result = $loginStatement->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];

            if ($user['role'] === 'admin') {
                $_SESSION['role'] = 'admin';
                header("Location: admin_dashboard.php");
            } else {
                $_SESSION['role'] = 'user';
                header("Location: user_dashboard.php");
            }
            exit();
        }
    }

    $_SESSION['login_error'] = "Invalid email or password!";
    $_SESSION['active_form'] = 'login-form';
    header("Location: index.php");
    exit();

}
