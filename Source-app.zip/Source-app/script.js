function showForm(formId) {
    document.querySelectorAll(".form-box").forEach(form => form.classList.remove("active"));    
    document.getElementById(formId).classList.add("active");
}

function togglePassword(toggleButton) {
    const passwordDetail = toggleButton.closest('.password-detail');
    const passwordValue = passwordDetail.querySelector('.password-value');
    const isExpanded = toggleButton.getAttribute('aria-expanded') === 'true';

    passwordValue.textContent = isExpanded
        ? passwordValue.dataset.hidden
        : passwordValue.dataset.visible;
    toggleButton.setAttribute('aria-expanded', String(!isExpanded));
    toggleButton.textContent = isExpanded ? 'Show' : 'Hide';
}

function toggleInputVisibility(eyeButton) {
    const passwordInput = eyeButton.closest('.password-input-group').querySelector('input');
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    eyeButton.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
}

function applyTheme(theme) {
    document.body.classList.toggle('dark-mode', theme === 'dark');
    const themeButton = document.querySelector('.theme-toggle');
    if (themeButton) {
        themeButton.textContent = theme === 'dark' ? 'Light mode' : 'Dark mode';
        themeButton.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    }
}

function toggleTheme() {
    const nextTheme = document.body.classList.contains('dark-mode') ? 'light' : 'dark';
    localStorage.setItem('theme', nextTheme);
    applyTheme(nextTheme);
}

function updatePasswordChecklist(passwordInput) {
    const panel = passwordInput.closest('form').querySelector('[data-password-panel]');
    if (!panel) {
        return;
    }

    const username = passwordInput.closest('form').querySelector('input[name="username"]')?.value.toLowerCase() || '';
    const email = passwordInput.closest('form').querySelector('input[name="email"]')?.value.toLowerCase() || '';
    const password = passwordInput.value;
    const lowerPassword = password.toLowerCase();
    const rules = {
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[^a-zA-Z0-9]/.test(password),
        length: password.length >= 8,
        repeat: password.length > 0 && !/(.)\1\1/.test(password),
        sequence: password.length > 0 && !/(?:012|123|234|345|456|567|678|789|987|876|765|654|543|432|321|210)/.test(password),
        keyword: password.length > 0 && !lowerPassword.includes(username) && !lowerPassword.includes(email)
    };

    let passedRules = 0;
    Object.entries(rules).forEach(([rule, passed]) => {
        const ruleElement = panel.querySelector(`[data-rule="${rule}"]`);
        ruleElement.classList.toggle('passed', passed);
        ruleElement.querySelector('.rule-icon').textContent = passed ? '\u2713' : '\u25cb';
        if (passed) {
            passedRules += 1;
        }
    });

    const strengthBar = panel.querySelector('[data-strength-bar]');
    const strengthLabel = panel.querySelector('[data-strength-label]');
    const strength = !password ? 'Unset' : passedRules <= 3 ? 'Weak' : passedRules <= 6 ? 'Medium' : 'Strong';
    strengthBar.className = strength.toLowerCase();
    strengthLabel.className = strength.toLowerCase();
    strengthLabel.textContent = strength;
}

document.addEventListener('DOMContentLoaded', () => {
    applyTheme(localStorage.getItem('theme') || 'light');
    const emailInput = document.querySelector('#login-form input[name="email"]');
    const rememberEmail = document.getElementById('remember-email');
    const loginForm = document.querySelector('#login-form form');
    const savedEmail = localStorage.getItem('rememberedEmail');

    if (savedEmail && emailInput) {
        emailInput.value = savedEmail;
        rememberEmail.checked = true;
    }

    loginForm?.addEventListener('submit', () => {
        if (rememberEmail.checked) {
            localStorage.setItem('rememberedEmail', emailInput.value.trim());
        } else {
            localStorage.removeItem('rememberedEmail');
        }
    });

    const roleSelect = document.querySelector('#register-form select[name="role"]');
    const adminPasswordField = document.getElementById('admin-password-field');
    const adminPasswordInput = adminPasswordField?.querySelector('input[name="admin_password"]');

    roleSelect?.addEventListener('change', () => {
        const isAdmin = roleSelect.value === 'admin';
        adminPasswordField.hidden = !isAdmin;
        adminPasswordInput.required = isAdmin;
        if (!isAdmin) {
            adminPasswordInput.value = '';
        }
    });

    document.querySelectorAll('[data-password-check]').forEach(passwordInput => {
        passwordInput.addEventListener('input', () => updatePasswordChecklist(passwordInput));
        passwordInput.closest('form').querySelectorAll('input[name="username"], input[name="email"]').forEach(identifierInput => {
            identifierInput.addEventListener('input', () => updatePasswordChecklist(passwordInput));
        });
        updatePasswordChecklist(passwordInput);
    });

});