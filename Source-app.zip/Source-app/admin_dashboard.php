<?php

session_start();
require_once 'config.php';
if (!isset($_SESSION['email']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php");
    exit();
}

$csrfToken = $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $submittedToken = $_POST['csrf_token'] ?? '';
    $userId = filter_var($_POST['user_id'] ?? '', FILTER_VALIDATE_INT);

    if (!hash_equals($csrfToken, $submittedToken) || !$userId) {
        $_SESSION['admin_message'] = 'The delete request was invalid.';
    } else {
        $deleteStatement = $conn->prepare("DELETE FROM users WHERE id = ? AND email <> ?");
        $deleteStatement->bind_param('is', $userId, $_SESSION['email']);
        $deleteStatement->execute();
        $_SESSION['admin_message'] = $deleteStatement->affected_rows > 0
            ? 'User deleted successfully.'
            : 'The active admin account cannot be deleted, or the user was not found.';
    }

    header("Location: admin_dashboard.php");
    exit();
}

$adminMessage = $_SESSION['admin_message'] ?? '';
unset($_SESSION['admin_message']);
$users = $conn->query("SELECT id, username, email, role FROM users ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="style.css?v=2">
</head>

<body>
    <button type="button" class="theme-toggle" onclick="toggleTheme()" aria-label="Switch theme">Dark mode</button>
    <div class="container dashboard-container">
        <h1>Welcome to the Admin Dashboard</h1>
        <p>Hello, <?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>! You are logged in as an admin.</p>
        <div class="account-details">
            <p><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><a href="index.php?form=forgot-form">Forgot password?</a></p>
        </div>
        <section class="users-section">
            <h2>Registered Users</h2>
            <?php if ($adminMessage): ?>
                <p class="admin-message"><?php echo htmlspecialchars($adminMessage, ENT_QUOTES, 'UTF-8'); ?></p>
            <?php endif; ?>
            <?php if ($users && $users->num_rows > 0): ?>
                <div class="users-table-wrapper">
                    <table class="users-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo (int) $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td><?php echo htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    <td>
                                        <form method="POST" action="admin_dashboard.php" onsubmit="return confirm('Delete this user account?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>">
                                            <button type="submit" name="delete_user" class="delete-button">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="empty-state">No users have been added yet.</p>
            <?php endif; ?>
        </section>
        <button onclick="window.location.href='logout.php'">Logout</button>
    </div>

    <script src="script.js?v=6"></script>
</body>


</html>