<?php

session_start();

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? '',
    'forgot' => $_SESSION['forgot_error'] ?? '',
    'success' => $_SESSION['login_success'] ?? ''

];
$activeForm = $_SESSION['active_form'] ?? ($_GET['form'] ?? 'login-form');

session_unset();

function showError($error) {
    return !empty($error) ? "<p class='error-message'>" . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . "</p>" : '';
}

function showSuccess($message) {
    return !empty($message) ? "<p class='success-message'>" . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . "</p>" : '';
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : '';
}

?>

<link rel="stylesheet" href="style.css?v=2">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User sign up, registeration, and seeing the Dashboard | Aryan Gopal</title>
    <link rel="stylesheet" href="style.css?v=2">
</head>

<body>
    <button type="button" class="theme-toggle" onclick="toggleTheme()" aria-label="Switch theme">Dark mode</button>
    <div class="container">
        <div class="form-box <?= isActiveForm('login-form', $activeForm); ?>" id="login-form">
            <form action = "login_register.php" method = "POST">
                <h2>Login</h2>
                <?= showError($errors['login']); ?>
                <?= showSuccess($errors['success']); ?>
                <input type="text" name="email" placeholder="Email or username" autocomplete="username" required>
                <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                <label class="remember-option"><input type="checkbox" id="remember-email"> Remember email on this device</label>
                <button type="submit" name ="login">Login</button>
                <p><a href="?form=forgot-form">Forgot password?</a></p>
                <p>Don't have an account? <a href="#" onclick="showForm('register-form'); return false;">Sign up</a></p>
            </form>

        </div>

        <div class="form-box <?= isActiveForm('forgot-form', $activeForm); ?>" id="forgot-form">
            <form action="login_register.php" method="POST">
                <h2>Forgot Password</h2>
                <?= showError($errors['forgot']); ?>
                <input type="text" name="username" placeholder="Username" autocomplete="username" required>
                <input type="email" name="email" placeholder="Email" autocomplete="email" required>
                <div class="password-input-group">
                    <input type="password" name="new_password" placeholder="New password" minlength="8" autocomplete="new-password" data-password-check required>
                    <button type="button" class="password-eye" aria-label="Show password" onclick="toggleInputVisibility(this)">&#128065;</button>
                </div>
                <div class="password-checklist" data-password-panel>
                    <h3>Your password must contain:</h3>
                    <p data-rule="uppercase"><span class="rule-icon">&#9675;</span> At least 1 uppercase letter</p>
                    <p data-rule="lowercase"><span class="rule-icon">&#9675;</span> At least 1 lowercase letter</p>
                    <p data-rule="number"><span class="rule-icon">&#9675;</span> At least 1 number</p>
                    <p data-rule="special"><span class="rule-icon">&#9675;</span> At least 1 special character</p>
                    <p data-rule="length"><span class="rule-icon">&#9675;</span> 8 or more characters</p>
                    <p data-rule="repeat"><span class="rule-icon">&#9675;</span> Max 2 repeating characters</p>
                    <p data-rule="sequence"><span class="rule-icon">&#9675;</span> Max 2 sequential numbers</p>
                    <p data-rule="keyword"><span class="rule-icon">&#9675;</span> Does not contain your username or email</p>
                    <div class="strength-meter"><span class="unset" data-strength-bar></span></div>
                    <strong>Password strength: <span class="unset" data-strength-label>Unset</span></strong>
                </div>
                <input type="password" name="confirm_password" placeholder="Confirm new password" minlength="8" autocomplete="new-password" required>
                <button type="submit" name="forgot_password">Change Password</button>
                <p><a href="?form=login-form">Back to login</a></p>
            </form>
        </div>

        <div class="form-box <?= isActiveForm('register-form', $activeForm); ?>" id="register-form">
            <form action = "login_register.php" method = "POST">
                <h2>Register</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="username" placeholder="Username" autocomplete="username" required>
                <input type="email" name="email" placeholder="Email" autocomplete="email" required>
                <div class="password-input-group">
                    <input type="password" name="password" placeholder="Password" minlength="8" autocomplete="new-password" data-password-check required>
                    <button type="button" class="password-eye" aria-label="Show password" onclick="toggleInputVisibility(this)">&#128065;</button>
                </div>
                <div class="password-checklist" data-password-panel>
                    <h3>Your password must contain:</h3>
                    <p data-rule="uppercase"><span class="rule-icon">&#9675;</span> At least 1 uppercase letter</p>
                    <p data-rule="lowercase"><span class="rule-icon">&#9675;</span> At least 1 lowercase letter</p>
                    <p data-rule="number"><span class="rule-icon">&#9675;</span> At least 1 number</p>
                    <p data-rule="special"><span class="rule-icon">&#9675;</span> At least 1 special character</p>
                    <p data-rule="length"><span class="rule-icon">&#9675;</span> 8 or more characters</p>
                    <p data-rule="repeat"><span class="rule-icon">&#9675;</span> Max 2 repeating characters</p>
                    <p data-rule="sequence"><span class="rule-icon">&#9675;</span> Max 2 sequential numbers</p>
                    <p data-rule="keyword"><span class="rule-icon">&#9675;</span> Does not contain your username or email</p>
                    <div class="strength-meter"><span class="unset" data-strength-bar></span></div>
                    <strong>Password strength: <span class="unset" data-strength-label>Unset</span></strong>
                </div>
                <select name="role" required>
                    <option value="" disabled selected>Select a Role</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
                <div id="admin-password-field" class="admin-password-field" hidden>
                    <input type="password" name="admin_password" placeholder="Register Admin Password" autocomplete="off">
                </div>
                <button type="submit" name="register">Register</button> 
                <p>Already have an account? <a href="#" onclick="showForm('login-form'); return false;">Login</a></p>
            </form>
        </div>
    </div>
    <script src="script.js?v=6"></script>
</body>
</html>